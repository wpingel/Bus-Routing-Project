__version__ = '0.8.5'
__VERSION__ = __version__
from .workbook import Workbook
